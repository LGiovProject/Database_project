package controller;

import model.domain.LoginUser;

public class AppController {

    LoginUser loginUser;
    public void start() {
        LoginController loginController = new LoginController();
        loginController.login();
        loginUser=loginController.getLogin();

        if(loginUser.getRole() == null) {
            throw new RuntimeException("Invalid credentials");
        }

        switch(loginUser.getRole()) {
            case MEDICO -> new DoctorController().start();
            case AMMINISTRATORE -> new AdministratorController().start();
            default -> throw new RuntimeException("Invalid credentials");
        }

    }


}
