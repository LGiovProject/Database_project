package controller;

import model.dao.*;

import model.domain.*;
import view.AdministratorView;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class AdministratorController {

    int choice;
    public void start(){

            try {

                ConnectionDB.changeRole(Role.AMMINISTRATORE);

            } catch(SQLException e) {
                    throw new RuntimeException(e);
                }
            while (true){
                    choice= AdministratorView.menuAdministrator();
                    switch(choice) {
                            case 1 -> insertMedicine();
                            case 2 -> insertBusiness();
                            case 3 -> insertBoxOfMedicine();
                            case 4 -> insertDeliveryBusiness();
                            case 5 -> insertAddressBusiness();
                            case 6 -> insertDrawer();
                            case 7 -> insertShelf();
                            case 8 -> insertUse();
                            case 9 -> insertUser();
                            case 10 -> assignUseToMedicine();
                            case 11 -> deleteBoxOfMedicine();
                            case 12 -> viewBusinessInfo();
                            case 13 -> viewMedicineInfo();
                            case 14 -> viewBusinessDelivery();
                            case 15 -> viewBusinessAddress();
                            case 16 -> viewMedicalUse();
                            case 17 -> generateReportBoxOfMedicineExpired();
                            case 18 -> generateReportWarehouseStock();
                            case 19 -> databaseReset();
                            case 20 -> System.exit(0);
                            default -> throw new RuntimeException("Invalid choice");


                    }
            }
    }


    //Operazioni Insert
    //Operazione 1
    public void insertMedicine(){
        try {
            InsertProcedureDAO.insertMedicine(AdministratorView.insertMedicine());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
    //Operazione 2
    public void insertBusiness(){

        try {
            InsertProcedureDAO.insertBusiness(AdministratorView.insertBusiness());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
    //Operazione 3
    public void insertBoxOfMedicine(){
        BoxOfMedicine bufferBoxOfMedicine;
        int buffer2;
        try {

            bufferBoxOfMedicine= AdministratorView.insertBoxOfMedicine();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        buffer2=InsertProcedureDAO.insertBoxOfMedicine(bufferBoxOfMedicine);
        AdministratorView.insertBoxOfMedicine(buffer2);
    }
    //Operazione 4
    private void insertDeliveryBusiness() {
        try {
            InsertProcedureDAO.insertDeliveryBusiness(AdministratorView.insertDeliveryBusiness());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
    //Operazion 5
    private void insertAddressBusiness() {
        try {
            InsertProcedureDAO.insertAddressBusiness(AdministratorView.insertAddressBusiness());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
    //Operazione 6
    private void insertDrawer() {
        int buffer1;
        int buffer2;
        try {
            buffer1= AdministratorView.insertDrawer();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        buffer2=InsertProcedureDAO.insertDrawer(buffer1);
        AdministratorView.insertDrawer(buffer2);
    }

    //Operazione 7
    private void insertShelf() {
        AdministratorView.insertShelf(InsertProcedureDAO.insertShelf());

    }

    //Operazione 8
    private void insertUse() {
        try {
            InsertProcedureDAO.insertUse(AdministratorView.insertUse());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    //Operazione 9
    private void insertUser() {
        LoginUser loginUser;
        try {
            loginUser = AdministratorView.insertUser();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        InsertProcedureDAO.insertUser(loginUser.getUsername(),loginUser.getPassword(),loginUser.getRole());

    }

    //Operazione 10
    private void assignUseToMedicine() {

        try {
            MedicalUse medicalUse = AdministratorView.assignUseToMedicine();
            InsertProcedureDAO.assignUseToMedicine(medicalUse.getUse(), medicalUse.getNameMedicine(),medicalUse.getNameBusiness());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
    //Operazioni delete
    //Operazione 11
    private void deleteBoxOfMedicine() {

        int buffer = AdministratorView.deleteBoxOfMedicine();
        DeleteProcedureDAO.deleteProcedureDAO(buffer);
    }

    //Operazioni view
    //Operazione 12
    private void viewBusinessInfo() {

        Business bufferBusiness;
        String buffer;
        try {
            buffer= AdministratorView.viewBusinessInfo();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        bufferBusiness =ViewProcedureDAO.viewBusiness(buffer);
        AdministratorView.viewBusinessInfo(bufferBusiness);
    }
    //Operazione 13
    private void viewMedicineInfo() {
        String buffer;
        List<Medicine> bufferMedicineList;
        try {
            buffer= AdministratorView.viewMedicineInfo();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        bufferMedicineList =ViewProcedureDAO.viewMedicineInfo(buffer);
        AdministratorView.viewMedicineInfo(bufferMedicineList);

    }
    //Operazione 14
    private void viewBusinessDelivery()
    {
        List<Delivery> bufferDeliveryList;
        String buffer;
        try {
            buffer= AdministratorView.viewBusinessDelivery();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        bufferDeliveryList =ViewProcedureDAO.viewBusinessDelivery(buffer);
        AdministratorView.viewBusinessDelivery(bufferDeliveryList);
    }
    //Operazione 15
    private void viewBusinessAddress()
    {
        List<Address> bufferAddressList;
        String buffer;
        try {
            buffer= AdministratorView.viewBusinessAddress();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        bufferAddressList =ViewProcedureDAO.viewBusinessAddress(buffer);
        AdministratorView.viewBusinessAddress(bufferAddressList);
    }
    //Operazione 16
    private void viewMedicalUse()
    {
        MedicalUse bufferMedicalUse;
        try {
            bufferMedicalUse= AdministratorView.viewMedicalUse();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        List<MedicalUse> medicalUseList = ViewProcedureDAO.viewMedicalUse(bufferMedicalUse.getNameMedicine(),bufferMedicalUse.getNameBusiness());
        AdministratorView.viewMedicalUse(medicalUseList);
    }

    //Operazioni report
    //Operazione 17
    private void generateReportBoxOfMedicineExpired() {

            List<BoxOfMedicine> bufferBoxOfMedicineList = ReportProcedureDAO.reportBoxOfMedicineExpiring();
            AdministratorView.generateReportBoxOfMedicineExpiring(bufferBoxOfMedicineList);

    }
    //Operazione 18
    private void generateReportWarehouseStock() {

        List<Medicine> bufferMedicineList = ReportProcedureDAO.reportWarehouseStock();
        AdministratorView.generateReportWarehouseStock(bufferMedicineList);

    }

    //Operazione 19

    private void databaseReset()  {
        LoginUser loginUser;
        try {
            loginUser = AdministratorView.databaseReset();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        DeleteProcedureDAO.databaseReset(loginUser.getUsername(),loginUser.getPassword());
    }












}

