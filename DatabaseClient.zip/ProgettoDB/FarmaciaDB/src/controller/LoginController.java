package controller;

import model.dao.LoginDAO;
import model.domain.LoginUser;
import view.LoginView;

import java.io.IOException;

public class LoginController {

    private LoginUser loginUser;

    public void login()
    {
        LoginView loginView = new LoginView();
        try {
           loginUser= loginView.login();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        loginUser= LoginDAO.checkLogin(loginUser.getUsername(),loginUser.getPassword());



    }


    public LoginUser getLogin()
    {
        return loginUser;
    }
}
