package view;

import model.domain.LoginUser;
import model.domain.Role;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class LoginView {

    public LoginUser login() throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Inserire il codice fiscale: ");
        String username = reader.readLine();
        System.out.print("Inserire la password: ");
        String password = reader.readLine();

        return new LoginUser(username,password);
    }
}
