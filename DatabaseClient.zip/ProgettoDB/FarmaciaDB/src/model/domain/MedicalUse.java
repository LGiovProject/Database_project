package model.domain;

public class MedicalUse {

    private String nameMedicine;
    private String use;

    private String nameBusiness;

    public MedicalUse(String nameMedicine, String use,String nameBusiness) {
        this.nameMedicine = nameMedicine;
        this.use = use;
        this.nameBusiness=nameBusiness;
    }

    public MedicalUse(String nameMedicine, String nameBusiness) {
        this.nameMedicine = nameMedicine;
        this.nameBusiness = nameBusiness;
    }

    public MedicalUse(){}
    public String getNameMedicine() {
        return nameMedicine;
    }

    public void setNameMedicine(String nameMedicine) {
        this.nameMedicine = nameMedicine;
    }

    public String getUse() {
        return use;
    }

    public void setUse(String use) {
        this.use = use;
    }

    public String getNameBusiness() {
        return nameBusiness;
    }

    public void setNameBusiness(String nameBusiness) {
        this.nameBusiness = nameBusiness;
    }
}
