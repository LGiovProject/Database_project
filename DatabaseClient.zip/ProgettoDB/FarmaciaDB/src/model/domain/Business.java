package model.domain;


public class Business {

    private String name;
    private String preferredAddress;
    private String preferredDelivery;
    private DeliveryType deliveryTypeOfDeliveryPreferred;






    public Business(String name, String preferredAddress, String preferredDelivery, int typeOfDeliveryPreferred) {
        this.name = name;
        this.preferredAddress = preferredAddress;
        this.preferredDelivery = preferredDelivery;
        this.deliveryTypeOfDeliveryPreferred = DeliveryType.fromInt(typeOfDeliveryPreferred);
    }

    public Business(){}


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPreferredAddress() {
        return preferredAddress;
    }

    public void setPreferredAddress(String preferredAddress) {
        this.preferredAddress = preferredAddress;
    }

    public String getPreferredDelivery() {
        return preferredDelivery;
    }

    public void setPreferredDelivery(String preferredDelivery) {
        this.preferredDelivery = preferredDelivery;
    }

    public String getTypeOfPreferredDelivery() {
        return deliveryTypeOfDeliveryPreferred.getType();
    }

    public void setTypeOfPreferredDelivery(String typeOfPreferredDelivery)
    {
        this.deliveryTypeOfDeliveryPreferred = DeliveryType.fromString(typeOfPreferredDelivery);
    }
    public void setTypeOfPreferredDelivery(int typeOfDeliveryPreferred) {
        this.deliveryTypeOfDeliveryPreferred = DeliveryType.fromInt(typeOfDeliveryPreferred);
    }

}
