package model.domain;

public class Address {

    private String nameBusiness;
    private String address;

    private int preferred;

    public Address(String nameBusiness, String address) {
        this.nameBusiness = nameBusiness;
        this.address = address;
        this.preferred =0;
    }

    public Address(){}
    public String getNameBusiness() {
        return nameBusiness;
    }

    public void setNameBusiness(String nameBusiness) {
        this.nameBusiness = nameBusiness;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getPreferred() {
        return preferred;
    }

    public void setPreferred(int preferred) {
        this.preferred = preferred;
    }
}
