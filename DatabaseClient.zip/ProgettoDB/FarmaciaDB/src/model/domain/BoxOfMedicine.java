package model.domain;
public class BoxOfMedicine {

    private int idBoxOfMedicine;
    private String business;
    private String nameMedicine;
    private int drawer;
    private int shelf;
    private String expiredDate;

    private Medicine medicine;

    public BoxOfMedicine(int idBoxOfMedicine, String expiredDate, int drawer, int shelf) {
        this.drawer = drawer;
        this.shelf = shelf;
        this.expiredDate = expiredDate;
        this.idBoxOfMedicine = idBoxOfMedicine;
        this.medicine = new Medicine();
    }

    public int getIdBoxOfMedicine() {
        return idBoxOfMedicine;
    }

    public void setIdBoxOfMedicine(int idBoxOfMedicine) {
        this.idBoxOfMedicine = idBoxOfMedicine;
    }

    public BoxOfMedicine(){
        this.medicine = new Medicine();
    }
    public String getBusiness() {
        return business;
    }

    public void setBusiness(String business) {
        this.business = business;
    }

    public String getNameMedicine() {
        return nameMedicine;
    }

    public void setNameMedicine(String medicine) {
        this.nameMedicine = medicine;
    }

    public int getDrawer() {
        return drawer;
    }

    public void setDrawer(int drawer) {
        this.drawer = drawer;
    }

    public int getShelf() {
        return shelf;
    }

    public void setShelf(int shelf) {
        this.shelf = shelf;
    }

    public String getExpiredDate() {
        return expiredDate.toString();
    }

    public void setExpiredDate(String expiredDate) {
       this.expiredDate = expiredDate;
    }

    public Medicine getMedicine(){return this.medicine;}
    public void setMedicine(Medicine medicine) {
        this.medicine = medicine;
    }
}
