package model.domain;

public enum Role {
    AMMINISTRATORE(1,"amministrazione"),
    MEDICO(2,"medico");

    private final int id;
    private final String name;
    private Role(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public static Role fromInt(int id) {
        for (Role type : values()) {
            if (type.getId() == id) {
                return type;
            }
        }
        return null;
    }
    public String getName(){return name;}

    public int getId() {
        return id;
    }
}
