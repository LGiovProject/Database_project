package model.domain;

public class Delivery {
    private String delivery;
    private DeliveryType deliveryType;
    private String business;
    private int preferred;

    public Delivery(String delivery, int type, String business) {
        this.delivery = delivery;
        this.deliveryType = DeliveryType.fromInt(type);
        this.business = business;
    }

    public Delivery(){}

    public String getDelivery() {
        return delivery;
    }

    public void setDelivery(String delivery) {
        this.delivery = delivery;
    }

    public String getDeliveryType() {
        return deliveryType.getType();
    }

    public void setDeliveryType(int type) {
        this.deliveryType = DeliveryType.fromInt(type);
    }

    public void setDeliveryType(String type){this.deliveryType = DeliveryType.fromString(type);}
    public String getBusiness() {
        return business;
    }

    public void setBusiness(String business) {
        this.business = business;
    }

    public void setPreferred(int preferred){this.preferred = preferred;}
    public int getPreferred() {
        return preferred;
    }


}
