package model.dao;

import model.domain.Medicine;
import model.domain.BoxOfMedicine;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ReportProcedureDAO {

        public static List<BoxOfMedicine> reportBoxOfMedicineExpiring() {

                List<BoxOfMedicine> boxOfMedicineList = new ArrayList<>();
                try {
                        Connection conn = ConnectionDB.getConnection();
                        CallableStatement cs = conn.prepareCall("{call report_medicinali_in_scadenza()}");
                        boolean status = cs.execute();

                        if (status) {
                                ResultSet rs = cs.getResultSet();
                                while (rs.next()) {
                                        BoxOfMedicine boxOfMedicine = new BoxOfMedicine(rs.getInt(1),rs.getString(2) ,rs.getInt(3), rs.getInt(4));
                                        boxOfMedicineList.add(boxOfMedicine);
                                }
                        }
                } catch (SQLException e) {
                        e.printStackTrace();
                }

                return boxOfMedicineList;
        }

        public  static List<Medicine> reportWarehouseStock(){

                List<Medicine> medicineStockList = new ArrayList<>();
                try {
                        Connection conn = ConnectionDB.getConnection();
                        CallableStatement cs = conn.prepareCall("{call report_giacenza_magazzino()}");
                        boolean status = cs.execute();

                        if (status) {
                                ResultSet rs = cs.getResultSet();
                                while (rs.next()) {
                                        Medicine medicine = new Medicine(rs.getString(1), rs.getString(2), rs.getInt(3));
                                        medicineStockList.add(medicine);
                                }
                        }
                } catch (SQLException e) {
                        e.printStackTrace();
                }

                return medicineStockList;
        }
}