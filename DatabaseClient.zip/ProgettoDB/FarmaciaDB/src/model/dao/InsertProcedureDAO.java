package model.dao;

import model.domain.*;

import java.sql.*;

public class InsertProcedureDAO {

        public static void insertMedicine(Medicine medicine)  {

            try {
                Connection conn = ConnectionDB.getConnection();
                CallableStatement cs = conn.prepareCall("{call inserisci_medicinale(?,?,?,?,?)}");
                cs.setString(1, medicine.getName());
                cs.setInt(2, medicine.getMutualita());
                cs.setInt(3, medicine.getPrescription());
                cs.setInt(4, medicine.getStock());
                cs.setString(5, medicine.getBusiness());
                cs.execute();
            }catch (SQLException e)
            {
                e.printStackTrace();
            }
        }

        public static void insertBusiness(Business business)  {
            try {
                Connection conn = ConnectionDB.getConnection();
                CallableStatement cs = conn.prepareCall("{call inserisci_ditta(?,?,?,?)}");
                cs.setString(1, business.getName());
                cs.setString(2, business.getPreferredDelivery());
                cs.setString(3, business.getTypeOfPreferredDelivery());
                cs.setString(4, business.getPreferredAddress());
                cs.execute();
            }catch (SQLException e)
    {
        e.printStackTrace();
    }
        }

        public static int insertBoxOfMedicine(BoxOfMedicine boxOfMedicine)  {
            int id = 0;
            try {
                Connection conn = ConnectionDB.getConnection();
                CallableStatement cs = conn.prepareCall("{call inserisci_scatola_medicinali(?,?,?,?,?,?)}");
                cs.setString(1, boxOfMedicine.getBusiness());
                cs.setString(2, boxOfMedicine.getNameMedicine());
                cs.setInt(3, boxOfMedicine.getDrawer());
                cs.setInt(4, boxOfMedicine.getShelf());
                cs.setString(5, boxOfMedicine.getExpiredDate());
                cs.registerOutParameter(6, Types.NUMERIC);
                cs.execute();
                id=cs.getInt(6);

            }catch (SQLException e)
            {
                e.printStackTrace();
            }
            return id;

        }

        public static void insertDeliveryBusiness(Delivery delivery) {
            try{
            Connection conn = ConnectionDB.getConnection();
            CallableStatement cs = conn.prepareCall("{call inserisci_recapito(?,?,?,?)}");
            cs.setString(1, delivery.getDelivery());
            cs.setString(2, delivery.getDeliveryType());
            cs.setString(3, delivery.getBusiness());
            cs.setInt(4, delivery.getPreferred());
            cs.execute();
            }catch (SQLException e)
            {
                e.printStackTrace();
            }

        }

        public static void insertAddressBusiness(Address address) {
            try{
            Connection conn = ConnectionDB.getConnection();
            CallableStatement cs = conn.prepareCall("{call inserisci_indirizzo(?,?,?)}");
            cs.setString(1, address.getAddress());
            cs.setString(2, address.getNameBusiness());
            cs.setInt(3, address.getPreferred());
            cs.execute();
            }catch (SQLException e)
            {
                e.printStackTrace();
            }
        }

        public static int insertDrawer(int shelf) {
            int idDrawer=0;
            try{
            Connection conn = ConnectionDB.getConnection();
            CallableStatement cs = conn.prepareCall("{call inserisci_cassetto(?,?)}");
            cs.setInt(1,shelf);
            cs.registerOutParameter(2,Types.NUMERIC);
            cs.execute();
            idDrawer=cs.getInt(2);
            }catch (SQLException e)
            {
                e.printStackTrace();
            }
            return idDrawer;
        }

        public static int insertShelf() {
            int idShelf=0;
            try{
            Connection conn = ConnectionDB.getConnection();
            CallableStatement cs = conn.prepareCall("{call inserisci_scaffale(?)}");
            cs.registerOutParameter(1,Types.NUMERIC);
            cs.execute();
            idShelf= cs.getInt(1);
            }catch (SQLException e)
            {
                e.printStackTrace();
            }
            return idShelf;


        }

        public static void insertUse(String use) {
            try{
            Connection conn = ConnectionDB.getConnection();

            CallableStatement cs = conn.prepareCall("{call inserisci_usi(?)}");
            cs.setString(1,use);
            cs.execute();
            }catch (SQLException e)
            {
                e.printStackTrace();
            }
        }

        public static void insertUser(String fiscalCode, String password, Role role)
        {
            try {
                Connection conn = ConnectionDB.getConnection();
                CallableStatement cs = conn.prepareCall("{call inserisci_utente(?,?,?)}");
                cs.setString(1,fiscalCode);
                cs.setString(2,password);
                cs.setString(3,role.getName());
                cs.execute();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }

        public static void assignUseToMedicine(String use, String nameMedicine,String nameBusiness)
        {
            try {
                Connection conn= ConnectionDB.getConnection();
                CallableStatement cs = conn.prepareCall("{call assegna_usi_medicinale(?,?,?)}");
                cs.setString(1,nameMedicine);
                cs.setString(2,use);
                cs.setString(3,nameBusiness);
                cs.execute();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }







}
