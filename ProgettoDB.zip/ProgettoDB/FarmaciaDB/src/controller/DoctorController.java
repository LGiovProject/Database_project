package controller;

import model.dao.ConnectionDB;
import model.dao.SellProcedureDAO;
import model.dao.ViewProcedureDAO;
import model.domain.BoxOfMedicine;
import model.domain.Medicine;
import model.domain.Role;
import view.DoctorView;

import java.io.IOException;
import java.sql.SQLException;

public class DoctorController {

    public void start(){



            try {

                ConnectionDB.changeRole(Role.MEDICO);

            } catch(SQLException e) {
                throw new RuntimeException(e);
            }

            while(true) {

                int choice;
                choice = DoctorView.menuMedico();

                switch(choice) {
                    case 1 -> makeSell();
                    case 2 -> makeSellFiscalCode();
                    case 3 -> findBoxOfMedicinePosition();
                    case 4 -> viewBoxOfMedicineInfo();
                    case 5 -> System.exit(0);
                    default -> throw new RuntimeException("Invalid choice");

                }

            }

    }

    //Operazioni sell
    //Operazione 1
    public void makeSell()
    {
        SellProcedureDAO.sellBoxOfMedicine(DoctorView.makeSell());
    }

    //Operazione 2
    public void makeSellFiscalCode()
    {
        try {
            SellProcedureDAO.sellBoxOfMedicineWithFiscalCode(DoctorView.makeSellWithFiscalCode());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    //Operazione 3
    public void findBoxOfMedicinePosition()
    {
        String buffer;
        Medicine bufferMedicine;
        try {
            buffer= DoctorView.findBoxOfMedicinePosition();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        bufferMedicine=ViewProcedureDAO.findBoxOfMedicineFromMedicine(buffer);
        DoctorView.findBoxOfMedicinePosition(bufferMedicine);
    }
    //Operazione 4
    public void viewBoxOfMedicineInfo()
    {
        int buffer = DoctorView.viewBoxOfMedicineInfo();
        BoxOfMedicine bufferBoxOfMedicine=ViewProcedureDAO.viewInfoBoxOfMedicine(buffer);
        DoctorView.viewBoxOfMedicineInfo(bufferBoxOfMedicine);
    }


}



