package model.domain;

public class Sell {

    private int idBoxOfMedicine;

    private String fiscalCode;


    public Sell(int idBoxOfMedicine) {
        this.idBoxOfMedicine = idBoxOfMedicine;
    }

    public Sell(int idBoxOfMedicine, String fiscalCode) {
        this.idBoxOfMedicine = idBoxOfMedicine;
        this.fiscalCode = fiscalCode;
    }

    public int getIdBoxOfMedicine() {
        return idBoxOfMedicine;
    }

    public void setIdBoxOfMedicine(int idBoxOfMedicine) {
        this.idBoxOfMedicine = idBoxOfMedicine;
    }

    public String getFiscalCode() {
        return fiscalCode;
    }

    public void setFiscalCode(String fiscalCode) {
        this.fiscalCode = fiscalCode;
    }
}
