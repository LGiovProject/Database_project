package model.domain;

public enum DeliveryType {

   FAX(1,"fax"),
    TELEFONO(2,"telefono"),

   EMAIL(3,"email");

    private final int id;
    private final String type;

    private DeliveryType(int id, String type) {
        this.id = id;
        this.type=type;
    }

    public static DeliveryType fromInt(int id) {
        for (DeliveryType type : values()) {
            if (type.getId() == id) {
                return type;
            }
        }
        return null;
    }

    public static DeliveryType fromString(String type){
        for(DeliveryType types: values())
        {
            if(types.getType().equals(type))
            {
                return types;
            }
        }
        return null;
    }

    public int getId() {
        return id;
    }

    public String getType(){return type;}
}
