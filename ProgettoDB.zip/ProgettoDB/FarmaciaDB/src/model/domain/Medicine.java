package model.domain;

import java.util.ArrayList;
import java.util.List;

public class Medicine {

    private String name;
    private int mutualita;
    private int prescription;
    private int stock;

    private List<BoxOfMedicine> boxOfMedicineList;
    private Business business;

    public Medicine() {
        business = new Business();
        boxOfMedicineList = new ArrayList<>();
    }


    public Medicine(String name, String ditta , int stock) {
        this.business = new Business();
        this.name = name;
        this.stock = stock;
        this.business.setName(ditta);
        boxOfMedicineList = new ArrayList<>();
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMutualita() {
        return mutualita;
    }

    public void setMutualita(int mutualita) {
        this.mutualita = mutualita;
    }

    public int getPrescription() {
        return prescription;
    }

    public void setPrescription(int prescription) {
        this.prescription = prescription;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getBusiness() {
        return business.getName();
    }

    public void setBusiness(String ditta) {
        this.business.setName(ditta);
    }

    public String getBusinessAddress() {
        return business.getPreferredAddress();
    }

    public void setBusinessAddress(String businessAddress) {
        this.business.setPreferredAddress(businessAddress);
    }

    public String getBusinessDelivery() {
        return business.getPreferredDelivery();
    }

    public void setBusinessDelivery(String businessDelivery) {
        this.business.setPreferredDelivery(businessDelivery);
    }

    public String getBusinessTypeOfDelivery() {
        return business.getTypeOfPreferredDelivery();
    }

    public void setBusinessTypeOfDelivery(String BusinessTypeOfDelivery) {
        this.business.setTypeOfPreferredDelivery(BusinessTypeOfDelivery);
    }

    public void setBusinessTypeOfDelivery(int dittaTypeOfDelivery){this.business.setTypeOfPreferredDelivery(dittaTypeOfDelivery);}

    public void addBoxOfMedicineList(BoxOfMedicine boxOfMedicine){this.boxOfMedicineList.add(boxOfMedicine);}


    public List<BoxOfMedicine> getBoxOfMedicineList(){
        return this.boxOfMedicineList;
    }
}
