package model.dao;

import model.domain.LoginUser;
import model.domain.Role;


import java.sql.*;

public class LoginDAO {

    public static LoginUser checkLogin(String username, String password) {
            int role = 0;
            try {
                    Connection conn = null;

                        conn = ConnectionDB.getConnection();
                        CallableStatement cs =conn.prepareCall("{call login(?,?,?)}");

                        cs.setString(1, username);
                        cs.setString(2, password);
                        cs.registerOutParameter(3,Types.NUMERIC);
                        cs.execute();
                        role=cs.getInt(3);


                    } catch (RuntimeException | SQLException e) {
                            throw new RuntimeException(e);
                    }

            return new LoginUser(username,password,Role.fromInt(role));
        }
}


