package model.dao;

import model.domain.Sell;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class SellProcedureDAO {

    public static void sellBoxOfMedicine(Sell sell)
    {
        try {
            Connection conn = ConnectionDB.getConnection();
            CallableStatement cs= conn.prepareCall("{call effettua_vendita(?,?)}");
            cs.setInt(1, sell.getIdBoxOfMedicine());
            cs.setString(2,null);
            cs.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public static void sellBoxOfMedicineWithFiscalCode(Sell sell)
    {
        try {
            Connection conn = ConnectionDB.getConnection();
            CallableStatement cs= conn.prepareCall("{call effettua_vendita(?,?)}");
            cs.setInt(1, sell.getIdBoxOfMedicine());
            cs.setString(2, sell.getFiscalCode());
            cs.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
