package model.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class DeleteProcedureDAO {

    public static void deleteProcedureDAO(int idBoxOfMedicine)
    {
        try {
            Connection conn = ConnectionDB.getConnection();
            CallableStatement cs= conn.prepareCall("{call elimina_scatola_medicinali(?)}");
            cs.setInt(1,idBoxOfMedicine);
            cs.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
}
