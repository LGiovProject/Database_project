package model.dao;

import model.domain.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ViewProcedureDAO {


    public static List<Medicine> viewMedicineInfo(String name) {

        List<Medicine> medicineList = new ArrayList<>();
        System.out.println(name);
        try {
            Connection conn = ConnectionDB.getConnection();
            CallableStatement cs = conn.prepareCall("{call visualizza_info_medicinale(?)}");
            cs.setString(1, name);
            boolean status = cs.execute();
            if (status) {
                ResultSet rs = cs.getResultSet();
                while (rs.next()) {
                    Medicine medicine = new Medicine();
                    medicine.setName(rs.getString(1));
                    medicine.setMutualita(rs.getInt(2));
                    medicine.setPrescription(rs.getInt(3));
                    medicine.setStock(rs.getInt(4));
                    medicine.setBusiness(rs.getString(5));
                    medicine.setBusinessAddress(rs.getString(6));
                    medicine.setBusinessDelivery(rs.getString(7));
                    medicine.setBusinessTypeOfDelivery(rs.getString(8));
                    medicineList.add(medicine);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return medicineList;
    }

    public static Business viewBusiness(String nome) {

        Business business = new Business();

        try {
            Connection conn = ConnectionDB.getConnection();
            CallableStatement cs = conn.prepareCall("{call visualizza_info_ditta(?)}");
            cs.setString(1, nome);
            boolean status = cs.execute();
            if (status) {

                ResultSet rs = cs.getResultSet();
                while (rs.next()) {
                    business.setName(rs.getString(1));
                    business.setPreferredAddress(rs.getString(2));
                    business.setPreferredDelivery(rs.getString(3));
                    business.setTypeOfPreferredDelivery(rs.getString(4));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return business;
    }

    public static BoxOfMedicine viewInfoBoxOfMedicine(int idBoxOfMedicine) {
        BoxOfMedicine boxOfMedicine = new BoxOfMedicine();
        Medicine medicine = new Medicine();
        Connection conn = null;
        try {
            conn = ConnectionDB.getConnection();

            CallableStatement cs = conn.prepareCall("{call visualizza_info_scatola_medicinale(?)}");
            cs.setInt(1, idBoxOfMedicine);
            boolean status = cs.execute();
            if (status) {
                ResultSet resultSet = cs.getResultSet();
                while (resultSet.next()) {
                    boxOfMedicine.setIdBoxOfMedicine(resultSet.getInt(1));
                    medicine.setName(resultSet.getString(2));
                    boxOfMedicine.setBusiness(resultSet.getString(3));
                    boxOfMedicine.setExpiredDate(resultSet.getString(4));
                    medicine.setMutualita(resultSet.getInt(5));
                    medicine.setPrescription(resultSet.getInt(6));
                    boxOfMedicine.setShelf(resultSet.getInt(7));
                    boxOfMedicine.setDrawer(resultSet.getInt(8));
                    boxOfMedicine.setMedicine(medicine);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return boxOfMedicine;
    }

    public static Medicine findBoxOfMedicineFromMedicine(String name) {
        Medicine medicine = new Medicine();
        try {
            Connection conn = ConnectionDB.getConnection();

            CallableStatement cs = conn.prepareCall("{call trova_posizione_scatole_da_medicinale(?)}");
            cs.setString(1, name);
            boolean status = cs.execute();
            if (status) {
                ResultSet rs = cs.getResultSet();
                while (rs.next()) {
                    BoxOfMedicine boxOfMedicine = new BoxOfMedicine();
                    boxOfMedicine.setIdBoxOfMedicine(rs.getInt(1));
                    boxOfMedicine.setBusiness(rs.getString(2));
                    boxOfMedicine.setShelf(rs.getInt(3));
                    boxOfMedicine.setDrawer(rs.getInt(4));
                    medicine.addBoxOfMedicineList(boxOfMedicine);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return medicine;
    }

    public static List<Address> viewBusinessAddress(String nameBusiness) {
        List<Address> addressList = new ArrayList<>();

        try {
            Connection conn = ConnectionDB.getConnection();
            CallableStatement cs = conn.prepareCall("{call visualizza_indirizzi_ditta(?)}");
            cs.setString(1, nameBusiness);
            boolean status = cs.execute();
            if (status) {
                ResultSet resultSet = cs.getResultSet();
                while (resultSet.next()) {
                    Address address = new Address();
                    address.setAddress(resultSet.getString(1));
                    address.setNameBusiness(resultSet.getString(2));
                    address.setPreferred(resultSet.getInt(3));
                    addressList.add(address);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return addressList;
    }

    public static List<Delivery> viewBusinessDelivery(String nameBusiness) {
        List<Delivery> deliveryList = new ArrayList<>();

        try {
            Connection conn = ConnectionDB.getConnection();
            CallableStatement cs = conn.prepareCall("{call visualizza_recapiti_ditta(?)}");
            cs.setString(1, nameBusiness);
            boolean status = cs.execute();
            if (status) {
                ResultSet resultSet = cs.getResultSet();
                while (resultSet.next()) {
                    Delivery delivery = new Delivery();
                    delivery.setDelivery(resultSet.getString(1));
                    delivery.setDeliveryType(resultSet.getString(2));
                    delivery.setBusiness(resultSet.getString(3));
                    delivery.setPreferred(resultSet.getInt(4));
                    deliveryList.add(delivery);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return deliveryList;
    }

    public static List<MedicalUse> viewMedicalUse(String nameMedicine,String nameBusiness) {

        List<MedicalUse> medicalUseList =new ArrayList<>();
        try {
            Connection conn = ConnectionDB.getConnection();
            CallableStatement cs = conn.prepareCall("{call visualizza_usi_medicinale(?,?)}");
            cs.setString(1, nameMedicine);
            cs.setString(2,nameBusiness);
            boolean status = cs.execute();
            if (status)
            {
                ResultSet resultSet = cs.getResultSet();
                while (resultSet.next()) {
                    MedicalUse medicalUse = new MedicalUse();
                    medicalUse.setUse(resultSet.getString(1));
                    medicalUse.setNameMedicine(resultSet.getString(2));
                    medicalUseList.add(medicalUse);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return medicalUseList;
    }
}