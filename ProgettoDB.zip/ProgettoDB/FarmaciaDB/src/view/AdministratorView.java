package view;



import model.domain.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Scanner;

public class AdministratorView {

    public static int menuAdministrator()
    {
        System.out.println("*********************************");
        System.out.println("*    Farmacia Amministrazione    *");
        System.out.println("*********************************\n");
        System.out.println("*** Cosa posso fare per te? ***\n");
        System.out.println("1) Inserisci Medicinale");
        System.out.println("2) Inserisci nuova ditta");
        System.out.println("3) Inserisci scatola di medicinali");
        System.out.println("4) Inserisci recapito per una ditta");
        System.out.println("5) Inserisci indirizzo per una ditta");
        System.out.println("6) Inserisci cassetto");
        System.out.println("7) Inserisci scaffale");
        System.out.println("8) Inserisci uso");
        System.out.println("9) Inserisci utente");
        System.out.println("10) Assegna uso");
        System.out.println("11) Elimina una scatola di medicinali");
        System.out.println("12) Visualizza informazioni su una ditta");
        System.out.println("13) Visualizza informazioni su un medicinale");
        System.out.println("14) Visualizza recapiti ditta");
        System.out.println("15) Visualizza indirizzi ditta");
        System.out.println("16) Visualizza usi di un medicinale");
        System.out.println("17) Genera report medicinali in scadenza");
        System.out.println("18) Genera report giacenza in magazzino");
        System.out.println("19) Quit");

        Scanner input = new Scanner(System.in);
        int choice;
        while (true) {
            System.out.print("Please enter your choice: ");
            choice = input.nextInt();
            if (choice >= 1 && choice <= 19) {
                break;
            }
            System.out.println("Invalid option");
        }
        return choice;


    }
    //Operazioni Insert
    //Operazione 1
    public static Medicine insertMedicine() throws IOException {
        Medicine medicine = new Medicine();
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Scanner input = new Scanner(System.in);
        System.out.println("Inserisci nome medicinale");
        medicine.setName(reader.readLine());
        System.out.println("Inserisci il nome della ditta fornitrice");
        medicine.setBusiness(reader.readLine());
        System.out.println("Inserisci se il medicinale è mutuabile: 1 per si 0 per no");
        medicine.setMutualita(input.nextInt());
        System.out.println("Inserisci se il medicinale ha bisogno di ricetta medica: 1 per si 0 per no");
        medicine.setPrescription(input.nextInt());
        System.out.println("Inserisci il numero di scorte del medicinale se ce ne sono");
        medicine.setStock(input.nextInt());
        return medicine;
    }
    //Operazione 2
    public static Business insertBusiness() throws IOException {

        Business business = new Business();
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Scanner input = new Scanner(System.in);
        System.out.println("Inserisci nome ditta");
        business.setName(reader.readLine());
        System.out.println("Inserisci l'indirizzo preferito");
        business.setPreferredAddress(reader.readLine());
        System.out.println("Inserisci il tipo del recapito preferito inserisci 1 per fax 2 per telefono e 3 per email ");
        business.setTypeOfPreferredDelivery(input.nextInt());
        System.out.println("Inserisci il recapito preferito");
        business.setPreferredDelivery(reader.readLine());
        return business;
    }

    //Operazione 3 input
    public static BoxOfMedicine insertBoxOfMedicine() throws IOException {
        BoxOfMedicine boxOfMedicine = new BoxOfMedicine();
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Scanner input = new Scanner(System.in);
        System.out.println("Inserisci il nome della ditta");
        boxOfMedicine.setBusiness(reader.readLine());
        System.out.println("Inserisci il nome del medicinale");
        boxOfMedicine.setNameMedicine(reader.readLine());
        System.out.println("Inserisci il numero dello scaffale");
        boxOfMedicine.setDrawer(input.nextInt());
        System.out.println("Inserisci il numero del cassetto");
        boxOfMedicine.setShelf(input.nextInt());
        System.out.println("Inserisci la data di scadenza Nel formato: Annno-mese-giorno  2024-12-25");
        boxOfMedicine.setExpiredDate(reader.readLine());
        return boxOfMedicine;

    }

    //Operazione 3 output
    public static void insertBoxOfMedicine(int id)
    {
        System.out.println("La nuova scatola inserita ha id: "+id);
    }


    //Operazione 4
    public static Delivery insertDeliveryBusiness() throws IOException {
        Delivery delivery = new Delivery();
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Scanner input= new Scanner(System.in);
        System.out.println("Inserisci il nome della ditta");
        delivery.setBusiness(reader.readLine());
        System.out.println("Inserisci il recapito: 1 per fax, 2 per telefono, 3 per email");
        delivery.setDeliveryType(input.nextInt());
        System.out.println("Inserisci il recapito");
        delivery.setDelivery(reader.readLine());
        return delivery;

    }

    //Operazione 5
    public static Address insertAddressBusiness() throws IOException {
        Address address = new Address();
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Inserisci il nome della ditta");
        address.setNameBusiness(reader.readLine());
        System.out.println("Inserisci l'indirizzo");
        address.setAddress(reader.readLine());
        return address;

    }
    //Operazione 6 input
    public static int insertDrawer() throws IOException {


        Scanner input = new Scanner(System.in);
        System.out.println("Inserisci lo scaffale in cui registrare il nuovo cassetto");
        return input.nextInt();
    }

    //Operazione 6 output
    public static void insertDrawer(int id)
    {
        System.out.println("Il cassetto inserito ha valore: "+id);
    }


    //Operazione 7
    public static void insertShelf(int id)
    {
        System.out.println("L'ultimo scaffale inserito ha id: "+id);
    }

    //Operazione 8
    public static String insertUse() throws IOException {
        System.out.println("Inserisci il nuovo uso");
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        return reader.readLine();

    }

    //Operazione 9
    public static LoginUser insertUser() throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        Scanner input= new Scanner(System.in);
        System.out.println("Inserisci il codice fiscale");
        String bufferFiscalCode = bufferedReader.readLine();
        System.out.println("Inserisci la password");
        String bufferPassword= bufferedReader.readLine();
        System.out.println("Inserisci 1 per registrare in amministrazione 2 per registrare tra il personale medico");
        Role bufferRole=Role.fromInt(input.nextInt());
        if(bufferRole!=null)
        {
            return new LoginUser(bufferFiscalCode,bufferPassword,bufferRole);
        }
        else
        {
            System.out.println("Inserito un valore diverso da 1 o da 2");
            System.exit(0);
        }

        return null;
    }

    //Operazione 10
    public static MedicalUse assignUseToMedicine() throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Inserisci l'uso");
        String bufferUse=br.readLine();
        System.out.println("Inserisci il medicinale");
        String bufferName=br.readLine();
        System.out.println("Inserisci nome ditta");
        String bufferBusiness=br.readLine();
        return new MedicalUse(bufferName,bufferUse,bufferBusiness);
    }

    //Operazione 11
    public static int deleteBoxOfMedicine()
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Inserisci l'id della scatola da eliminare");
        return input.nextInt();
    }


    //Operazioni view
    //Operazione 12 input
    public static String viewBusinessInfo() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Inserire il nome della ditta di cui si vogliono le informazioni");
        return reader.readLine();
    }

    //Operazioni 12 output
    public static void viewBusinessInfo(Business business)
    {
        System.out.println("Nome ditta: "+ business.getName());
        System.out.println("Indirizzo preferito: "+ business.getPreferredAddress());
        System.out.println("Recapito preferito: "+ business.getPreferredDelivery());
        System.out.println("Tipo del recapito preferito: "+ business.getTypeOfPreferredDelivery());
    }

    //Operazione 13 input
    public static String viewMedicineInfo() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Inserire il nome del medicinale di cui si vogliono le informazioni");
        return reader.readLine();
    }

    //operazioni 13 output
    public static void viewMedicineInfo(List<Medicine> medicineList)
    {
        for(Medicine medicine : medicineList)
        {
            System.out.println("\n\n");
            System.out.println("Nome medicinale: " + medicine.getName());
            System.out.println("Mutualità: " + medicine.getMutualita());
            System.out.println("Ricetta Medica: " + medicine.getPrescription());
            System.out.println("Scorte: " + medicine.getStock());
            System.out.println("Nome ditta: " + medicine.getBusiness());
            System.out.println("Indirizzo ditta: " + medicine.getBusinessAddress());
            System.out.println("Recapito ditta: " + medicine.getBusinessDelivery());
            System.out.println("Tipologia recapito: " + medicine.getBusinessTypeOfDelivery());
            System.out.println("\n");
        }
    }

    //Operazione 14 input
    public static String viewBusinessDelivery() throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Inserisci il nome della ditta di cui vuoi vedere i recapiti");
        return bufferedReader.readLine();
    }

    //Operazione 14 output
    public static void viewBusinessDelivery(List<Delivery> deliveryList)
    {
        System.out.println("\n");
        System.out.println("Questi sono i recapiti della ditta: "+ deliveryList.getFirst().getBusiness());
        for(Delivery delivery : deliveryList)
        {
            System.out.println("recapito: "+ delivery.getDelivery());
            System.out.println(delivery.getDeliveryType());
            System.out.println((delivery.getPreferred()==1?"E' il recapito preferito":"Non è il recapito preferito"));
            System.out.println("\n");
        }
    }

    //Operazione 15 input
    public static String viewBusinessAddress() throws IOException {

        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Inserisci il nome della ditta di cui vuoi vedere gli indirizzi");
        return bufferedReader.readLine();
    }

    //Operazione 15 output
    public static void viewBusinessAddress(List<Address> addressList)
    {
        System.out.println("\n");
        System.out.println("Questi sono gli indirizzi per la ditta: "+ addressList.getFirst().getNameBusiness());
        for (Address address : addressList)
        {
            System.out.println("Via: "+ address.getAddress());
            System.out.println((address.getPreferred()==1?"E' l'indirizzo preferito":"Non è l'indirizzo preferito"));
            System.out.println("\n");
        }
    }

    //Operazione 16 input
    public static MedicalUse viewMedicalUse() throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Inserisci il nome del medicinale di cui vuoi vedere gli usi");
        String bufferNameMedicine=bufferedReader.readLine();
        System.out.println("inserisci il nome della ditta");
        String bufferNameBusiness=bufferedReader.readLine();
        return new MedicalUse(bufferNameMedicine,bufferNameBusiness);

    }

    //Operazione 16 output
    public static void viewMedicalUse(List<MedicalUse> medicalUseList)
    {
        System.out.println("\n");
        if(medicalUseList.isEmpty())
        {
            System.out.println("Non ci sono usi registrati per questo medicinale\n");

        }
        else
        {
            System.out.println("Questi sono gli usi del medicinale: "+ medicalUseList.getFirst().getNameMedicine());
            for(MedicalUse medicalUse : medicalUseList)
            {
                System.out.println("Uso: "+ medicalUse.getUse());
                System.out.println("\n");
            }
        }
    }


    //Operazioni report
    //Operazione 17
    public static void generateReportWarehouseStock(List<Medicine> medicineStockList) {

        for(Medicine medicine : medicineStockList)
        {
            System.out.println("\n");
            System.out.println("Nome medicinale: "+ medicine.getName());
            System.out.println("Nome ditta: "+ medicine.getBusiness());
            System.out.println("Scorte: "+ medicine.getStock());
            System.out.println("\n");
        }
    }

    //Operazione 18
    public static void generateReportBoxOfMedicineExpiring(List<BoxOfMedicine> boxOfMedicineList) {


        for(BoxOfMedicine boxOfMedicine : boxOfMedicineList)
        {
            System.out.println("");
            System.out.println("Id_scatolla: "+ boxOfMedicine.getIdBoxOfMedicine());
            System.out.println("Data scadenza: "+ boxOfMedicine.getExpiredDate());
            System.out.println("Cassetto: "+ boxOfMedicine.getShelf());
            System.out.println("Scaffale: "+ boxOfMedicine.getDrawer());
            System.out.println("\n");
        }
    }








}
