package view;

import model.domain.Medicine;
import model.domain.BoxOfMedicine;
import model.domain.Sell;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class DoctorView {

    public static int menuMedico()
    {

        System.out.println("*********************************");
        System.out.println("*    Farmacia personale medico    *");
        System.out.println("*********************************\n");
        System.out.println("*** Cosa posso fare per te? ***\n");
        System.out.println("1) Effettua vendita");
        System.out.println("2) Effettua vendita con codice fiscale");
        System.out.println("3) Trova posizione scatole di un medicinale");
        System.out.println("4) Visualizza info scatola di medicinali");
        System.out.println("5) Quit");

        Scanner input = new Scanner(System.in);
        int choice;
        while (true) {
            System.out.print("Please enter your choice: ");
            choice = input.nextInt();
            if (choice >= 1 && choice <= 5) {
                break;
            }
            System.out.println("Invalid option");
        }

        return choice;
    }

    //Operazioni sell
    //Operazione 1
    public static Sell makeSell()
    {

        Scanner input = new Scanner(System.in);
        System.out.println("Inserisci l'id della scatola da vendere");
        return new Sell(input.nextInt());
    }

    //Operazione 2
    public static Sell makeSellWithFiscalCode() throws IOException {
        Scanner input = new Scanner(System.in);
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Inserisci l'id dellla scatola da vendere");
        int id= input.nextInt();
        System.out.println("Inserisci il codice fiscale");
        String codiceF = bufferedReader.readLine();
        return new Sell(id,codiceF);
    }
    //Operazioni view
    //Operazione 3 input
    public static String findBoxOfMedicinePosition() throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Inserisci il nome del medicinale del quale vuoi trovare le scatole");
        return bufferedReader.readLine();
    }

    //Operazione 3 output
    public static void findBoxOfMedicinePosition(Medicine medicine)
    {
        for (BoxOfMedicine boxOfMedicine : medicine.getBoxOfMedicineList())
        {
            System.out.println("Id della scatola: "+ boxOfMedicine.getIdBoxOfMedicine());
            System.out.println("Nome ditta: "+ boxOfMedicine.getBusiness());
            System.out.println("Scaffale: "+ boxOfMedicine.getDrawer());
            System.out.println("Cassetto: "+ boxOfMedicine.getShelf());
            System.out.println("\n\n");
        }
    }

    //Operazione 4 input
    public static int viewBoxOfMedicineInfo()
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Inserire l'id della scatola di cui si vogliono le informazioni");
        return input.nextInt();
    }

    //Operazione 4 output
    public static void viewBoxOfMedicineInfo(BoxOfMedicine boxOfMedicine)
    {

            System.out.println("Id della scatola: "+ boxOfMedicine.getIdBoxOfMedicine());
            System.out.println("Nome medicinale: "+ boxOfMedicine.getMedicine().getName());
            System.out.println("Nome ditta: "+ boxOfMedicine.getBusiness());
            System.out.println("Ricetta Medica: "+ boxOfMedicine.getMedicine().getPrescription());
            System.out.println("Mutuabilità: "+ boxOfMedicine.getMedicine().getMutualita());
            System.out.println("Scaffale: "+ boxOfMedicine.getDrawer());
            System.out.println("Cassetto: "+ boxOfMedicine.getShelf());

    }
}
